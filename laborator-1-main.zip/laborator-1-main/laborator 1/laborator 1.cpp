// laborator 1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    int n, x;
    cout << "n= ";
    cin >>n;
	cout << "x=";
	cin >> x;
	cout << "8.1" << "\n";
    cout << "1)n*8=" << ( n << 3) << "\n";
    cout << "2)n/4=" << (n >> 2) << "\n";
    cout << "3)n*10=" << (n<<3)+(n<<1) <<  "\n";
	cout << "8.2) ";
	if ( (n & 1 ) ==1)
		cout << "numar impar" << "\n ";
	else 
		cout << "numar par" << "\n";
	cout << "8.3) ";
	bool bit = n&(1<<x);
		cout<<" bitul de pe pozitia  " << x << " este urmatorul: " << bit<< "\n";
	cout << "8.4) ";
	
	getch();
}



