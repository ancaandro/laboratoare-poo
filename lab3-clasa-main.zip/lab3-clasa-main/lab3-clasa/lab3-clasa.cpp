// lab3-4.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <conio.h>
#include <string.h>
using namespace std;

int an, grupa, varsta,r=1;
char nume[10], prenume[10];    
class student
{
public:
char nume[10];
char prenume[10];
int an;
int grupa;
int varsta;
void citire ( char *cnume, char *cprenume, int *a, int *g, int *v);
void afisare();

};
 
void student::citire (  char *cnume, char *cprenume, int *a, int *g, int *v)
{
strcpy (nume,cnume);
strcpy (prenume, cprenume);
an=*a;
grupa=*g;
varsta=*v;
}
 void student::afisare ()
 {
cout << "\n nume:" << nume << " prenumele: " << prenume;
cout << "\n an: " << an << " grupa: " << grupa << " varsta: " << varsta;
 }
int main()
{
student vstudent;

		cout << "student \n numele: ";
		gets(nume);
		cout << "\n prenumele: ";
		gets( prenume);
		cout << "\n an: ";
		cin >> an;
		cout << "\n grupa: ";
		cin >> grupa;
		cout << "\n varsta: ";
		cin >> varsta;

getch();
return 0;
}
